<?php
session_start();
$conn = mysqli_connect("localhost","root","","car rental office");
if(!$conn){
    echo 'خطأ';
}


?>